const courses=[
 {icon:"📐",title:"Mathematics Fundamentals",level:"Beginner • 24 lessons",rating:"4.9",price:"$18"},
 {icon:"📚",title:"English Language Skills",level:"Intermediate • 20 lessons",rating:"4.8",price:"$15"},
 {icon:"🔬",title:"General Science",level:"Beginner • 18 lessons",rating:"5.0",price:"$20"}
];
const grid=document.getElementById("courseGrid");
grid.innerHTML=courses.map(c=>`<article class="card"><div class="course-icon">${c.icon}</div><h3>${c.title}</h3><p>${c.level}</p><strong>★ ${c.rating}</strong><p><b>${c.price}</b></p><button class="btn" onclick="openModal('signup')">Enroll Now</button></article>`).join("");

function openModal(type){
 document.getElementById("modal").classList.add("show");
 document.getElementById("modalTitle").textContent=type==="login"?"Welcome back":"Create your account";
 document.getElementById("nameField").style.display=type==="login"?"none":"block";
}
function closeModal(){document.getElementById("modal").classList.remove("show")}
document.getElementById("modal").addEventListener("click",e=>{if(e.target.id==="modal")closeModal()});
document.getElementById("authForm").addEventListener("submit",e=>{
 e.preventDefault();
 const name=document.getElementById("nameField").value||"Learner";
 localStorage.setItem("learnerName",name);
 closeModal();
 alert(`Welcome, ${name}! This Phase 1 prototype is ready. The next phase adds a real database, authentication and student dashboard.`);
});
